# Redux Store

```js
{
    'authentication': ''
    'notebooks': {
        'dict': {
            '0': {
                'id': '0',
                'title': 'Notebook of Stuff',
                'note_ids': ['0']
            }
        },
        'ids': ['0']
    },
    'notes': {
        'dict': {
            '0': {
                'id': '0',
                'title': 'My Note',
                'content': 'This is a note. It\'s my first note.'
                'tag_ids': [],
                'notebook_id': ''
            }
        },
        'ids': ['0']
    },
    'tags': {
        dict: {
            '0': {
                'id': '',
                'title': '',
                'note_ids': []
            }
        },
        'ids': []
    },
    'ui': {
        'current_notebook': '',
        'current_note': '',
        'current_tag': '',
        'display_tag_panel': False,
        'display_logout_panel': False,
    },
    'user': {
        'username': '',
        'email': '',
        'avatar': '',
        'created_at': '',
    },
}
```