# Rich-Text Editing

## COMPONENTS NEEDED

- Editor (see components.md)

## MODELS NEEDED

- notes

## ENDPOINTS NEEDED

- routes already exist
