# Tags

## COMPONENTS NEEDED

- TagPanel
- TagEditor

## MODELS NEEDED

- tags
- notes

## ENDPOINTS NEEDED

- /users/:id/tags/ POST
- /users/:id/tags/:id DELETE
- (for linking existing tag, see route in notes)
