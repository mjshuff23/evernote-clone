import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles(theme => ({
  notebookpanel: {
    padding: 30,
    width: '100%'
  }
}));

export default useStyles;
