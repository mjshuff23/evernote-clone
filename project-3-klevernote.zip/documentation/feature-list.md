# Feature List

- MVP FEATURES
  - Notes
  - Notebooks
  - Tags
  - Rich-text editing
- STRETCH FEATURES
  - Auto save
  - Search
  - Reminders
