# Notebooks 

## COMPONENTS NEEDED

- Notebook Panel

## MODELS NEEDED

- notebooks

## ENDPOINTS NEEDED

- /users/:id/notebooks POST
- /users/:id/notebooks/:id PUT
- /users/:id/notebooks/:id DELETE
