# Notes

## COMPONENTS NEEDED

- TagContainer
- NoteInfoPanel

## MODELS NEEDED

- notes

## ENDPOINTS NEEDED

- /users/:id/notebooks/:id/notes/ POST
- /users/:id/notebooks/:id/notes/:id PUT
- /users/:id/notebooks/:id/notes/:id DELETE
- /users/:id/notebooks/:id/notes/:id/tags/:id POST
